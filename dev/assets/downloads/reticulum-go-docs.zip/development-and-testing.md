# Development and testing

See [CONTRIBUTING.md](https://github.com/Quad4-Software/Reticulum-Go/blob/master/CONTRIBUTING.md) for commit format, pull request checklist, and CI overview.

## Development environment

Requirements:

- Go 1.27.4 or later (see scripts/ci/dev-tools.env and mise.toml)
- Make (or plain `go` commands)
- revive and staticcheck (`make bootstrap` installs pinned versions)
- shellcheck and yamllint (optional system packages)
- Python 3 for crossref vector generation (optional)

Clone the repository. Dependencies are in vendor/. No network fetch is needed for ordinary builds.

Setup:

```bash
make bootstrap
make doctor
```

Run `make help` for available targets. Plain `go` commands work too. The Makefile sets `GOFLAGS=-mod=vendor`, `GOPROXY=off`, and `GOSUMDB=off`, so export those if you bypass it.

A Taskfile also exists for maintainer and CI automation (`task --list`), but it is not required for contributing. Everything below works with Make or plain shell.

Optional: [mise](https://mise.jdx.dev/) (mise install) or the Dev Container (.devcontainer/).

## Portable CI (Forgejo, Gitea, local, Podman)

Same PR gate as `task check`, without GitHub Marketplace actions:

| Command | Role |
| --- | --- |
| `bash scripts/ci/bootstrap-toolchain.sh install` | Pinned Go, Task, revive, staticcheck |
| `CI_SKIP_TREE_VERIFY=1 bash scripts/ci/run.sh pr` | PR gate without `reticulum-go.rsm` verify |
| `bash scripts/ci/run-docker.sh pr` | PR gate in `scripts/ci/Dockerfile.ci` (Podman if available) |
| `task ci:pr` / `make ci-pr` | Wrappers for `run.sh pr` |
| `task ci:docker` / `make ci-docker` | Wrapper for `run-docker.sh pr` |

Forgejo: `.forgejo/workflows/ci.yml` runs bootstrap plus `run.sh`.

Pinned versions: `scripts/ci/versions.env` and `scripts/ci/dev-tools.env`.

## Build automation reference

| Make | Manual / notes |
|------|----------------|
| `make` / `make all` / `make build` | `mkdir -p bin && CGO_ENABLED=0 go build -ldflags="-s -w" -o bin/reticulum-go ./cmd/reticulum-go` |
| `make install` | Installs binary, legacy tool symlinks, and man pages under `PREFIX` (supports `DESTDIR`) |
| `make install-man` | Man pages only |
| `make install-service` | `INIT=auto\|systemd\|openrc\|runit\|dinit\|all`. Sample config under `/var/lib/reticulum-go` |
| `make uninstall` | Removes installed binary, symlinks, and man pages |
| `make package-deb` / `package-rpm` / `package-arch` | nfpm packages into `dist/` |
| `make clean` | `go clean` and remove build artifacts |
| `make test` | `go test -v ./...` (project wrapper may use testsummary) |
| `make test-short` | `go test -short -v ./...` |
| `make test-race` | `CGO_ENABLED=1 go test -race -v ./...` |
| `make test-services` | `scripts/ci/test-services-docker.sh` |
| `make test-install-script` | `scripts/ci/test-install.sh` |
| `make test-self-check` | `scripts/ci/run-self-check.sh` |
| `make test-self-check-{386,arm,riscv64,ppc64le,ppc64}` | qemu-user self-check (`qemu-user-static`) |
| `make coverage` | coverage profile and HTML report |
| `make bench` | `go test -run=^$ -bench=. -benchmem ./...` |
| `make fmt` | `go fmt ./...` |
| `make vet` | `go vet ./...` |
| `make lint` | revive with `revive.toml` |
| `make staticcheck` | staticcheck on core packages |
| `make vulncheck` | govulncheck |
| `make check` | fmt/vet/lint/staticcheck/short tests/vulncheck (gosec via Make) |
| `make prepush` | fmt-check, vet, lint, test-short |
| `make deps` / `make vendor-sync` | module download/verify and re-vendor from `LIBS_ROOT` |
| `make run` | `go run ./cmd/reticulum-go` |
| `make debug` | `go build -o bin/reticulum-go ./cmd/reticulum-go` |
| `make build-linux` / `build-windows` / `build-darwin` / `build-all` | Cross-compile release targets |
| `make build-windows-legacy` | go-legacy-win7 (`GO_LEGACY_WIN7`) |
| `make build-windows-xp` | go-legacy-winxp (`GO_LEGACY_WINXP`) |
| `make build-librns` | `CGO_ENABLED=1 go build -buildmode=c-shared -o bin/librns.so ./cmd/librns` |
| `make test-wasm` | js/wasm package tests (Node exec helper) |
| `make build-wasm` | `GOOS=js GOARCH=wasm go build -ldflags="-s -w" -o bin/reticulum-go.wasm ./cmd/reticulum-wasm` |
| `make microvm-up` / `microvm-stop` | Firecracker guest. See [microvm](microvm.md) |
| `make tree-rsm-verify` / `tree-rsm-sign` | Source tree `.rsm` inventory. See [SECURITY.md](https://github.com/Quad4-Software/Reticulum-Go/blob/master/SECURITY.md) |
| `make doctor` / `bootstrap` / `changelog-preview` | Dev tool pins and CHANGELOG preview |

## Code quality commands

```bash
make fmt && make vet && make lint && make check
# or
make fmt
make vet
make lint
make staticcheck
make test-short
make vulncheck
make prepush      # fast path before git push
make check        # full local check suite
make ci           # same static checks as CI lint job
```

`make check` runs fmt, vet, lint, staticcheck, test-short, vulncheck, and gosec.

### Linting

revive with project config:

```bash
revive -config revive.toml -formatter friendly ./pkg/* ./cmd/* ./internal/*
```

staticcheck:

```bash
staticcheck -tests=false ./pkg/... ./cmd/... ./internal/... ./tests/...
```

### Changelog preview

Preview unreleased notes from conventional commits:

```bash
make changelog-preview
```

Uses cliff.toml and git-cliff (installed via go run when not on PATH).

### Race detector

```bash
make test-race
```

Transport and interface packages include dedicated race and deadlock regression tests (interface_stress_race_test.go, pipe_race_test.go, pipe_deadlock_test.go).

### Coverage

```bash
make coverage
```

Opens HTML coverage from coverage.out.

### Benchmarks

```bash
make bench
make test-bench-gate
```

Loopback link throughput smoke (RNS Speedtest-style liveness floor):

```bash
make test-link-speed
reticulum-go speedtest
```

Nightly sim-heavy also runs test-link-speed.

## Project layout for contributors

| Path | Purpose |
|------|---------|
| pkg/ | Public library code |
| cmd/ | Binaries and e2e tests |
| internal/ | Daemon-only code |
| tests/crossref/ | Python vector parity |
| tests/interop/ | Live Go/Python tests |
| scripts/ci/ | CI install and release scripts |
| .github/workflows/ | GitHub Actions |

Follow existing naming, error wrapping, and SPDX headers in each file.

## Testing layers

| Layer | How to run | What it covers |
|-------|------------|----------------|
| Unit | make test / make test-short | Package *_test.go |
| Property | make test-property | *_pbt_test.go and embedded github.com/Quad4-Software/pbt / testing/quick |
| Mutation | make test-mutation | gomutant on cryptography, packet, announce, destination, identity, ifac, backbone, interfaces |
| Chaos | make test-chaos / make test-soak / make test-soak-protect | TestSimChaos* / TestLinkChaos* / TestIfaceChaos* plus soak, including dos_protection flood soak |
| Oracle | make test-oracle | Crossref vectors, health TransportCounters deltas, adversarial corpus |
| Smoke | make test-binary-smoke, binding smokes | Binary --version/--help, CLI dump via Main, librns smoke examples |
| Acceptance | make test-acceptance | librns SCAFFOLD minimum, control API acceptance |
| E2E | make test-e2e | Daemon reload, UDP path e2e, transport TestE2E_* |
| Black box | make test-blackbox | CLI Main / rgodump surface, control API HTTP acceptance |
| Interop | RUN_LIVE_INTEROP=1 go test ./tests/interop/... | Live Go<->Python (optional locally), including dos_protection live suites |

### Unit tests

Standard go test in each package. Run all:

```bash
go test -v ./...
```

Short mode skips long tests:

```bash
go test -short -v ./...
```

### Property-based tests

Files named *_pbt_test.go use github.com/Quad4-Software/pbt for generative testing (cryptography, packet, buffer, rate, resource, announce, link, identity). Some properties still live beside unit tests in the same package.

```bash
make test-property
```

### Mutation tests

In-repo tools/gomutant flips same-width operators and re-runs package tests.

```bash
make test-mutation
```

Default packages: cryptography, packet, announce, destination, identity, ifac, backbone, interfaces. Override with MUTATION_PACKAGES / MUTATION_THRESHOLD.

### Fuzz tests

Files named *_fuzz_test.go cover packet, link, ifac, blackhole, discovery, health counters (pkg/health), pipe HDLC framing (pkg/interfaces/pipe_fuzz_test.go), and librns (pkg/librns).

### Chaos and fault injection

Seeded loss, reorder, corruption, and flap tests across layers:

| Prefix | Package | Focus |
|--------|---------|-------|
| TestSimChaos* | pkg/transport | Multi-node path and announce under delay/loss/corrupt/reorder/flap (health oracle deltas on corrupt) |
| TestLinkChaos* | pkg/link | Establish, packet under loss/reorder, resource under capped drop, mid-session flap, goroutine budget |
| TestIfaceChaos* | pkg/interfaces | TCP HDLC corrupt/reorder, Local corrupt resync, Pipe respawn, Backbone reconnect |

```bash
make test-chaos
make test-soak
make test-soak-protect
```

Chaos suites are in-process Go only (sim pipes / HDLC fixtures). Live Go<->Python HDLC loss, reorder, corrupt, and mid-session flap live under tests/interop/ (TestLiveInteropHDLC*, RUN_LIVE_INTEROP=1). Unpack hop-gate, HT2 truncation, oversize, and Pack/Unpack byte-identity vs Python RNS.Packet live in unpack_live_test.go. Healthy-path cross-stack coverage also lives under tests/interop/.

### dos_protection tests

pkg/protect and interface hooks cover false positives, false negatives, auto learn/persist/relearn, and live sockets.

| Suite | Location | Focus |
|-------|----------|-------|
| Unit / FP-FN | pkg/protect/false_positive_test.go | Quiet traffic, bursty legit, multi-iface isolation, oscillation, poisoned warmup, drift without false block |
| Snapshot / bitrate / priority | pkg/protect/snapshot_test.go, bitrate_test.go, packetclass.go | Status snapshot, scaled floors, prefer-keep shedding |
| Harm / FP oracles | pkg/protect/harm_oracle_test.go | Quiet mesh, slow radio, bulk link after quiet learn, path requests during announce floods, massive discovery bursts, peer isolation vs resource streams, auto-learning flood contract |
| Transport handler shed | pkg/transport/protect_test.go | Semaphore-full always sheds in detect, prevent, and auto learning |
| Slow findings | pkg/rnsutil/slow_protect_test.go | dos_armed_trips and cool-down findings from RPC protect block |
| Sandbox soft-fail | pkg/sandbox/warn_test.go | Rate-limited stdout when Landlock or seccomp soft-fails |
| Replay traces | pkg/protect/replay_trace_test.go | Mesh-like timelines, flood inject and recovery, auto learn then block |
| Property / fuzz | pkg/protect/property_test.go, fuzz_test.go | Detect never blocks, prevent after threshold, mode round-trip |
| Soak | make test-soak-protect | Bounded flood heap and goroutine budgets |
| Live UDP/TCP | pkg/interfaces/protect_*_live_test.go | Real loopback sockets, optional non-loopback NIC, TCP accept storms |
| Live interop | tests/interop/dos_protect_live_test.go | RUN_LIVE_INTEROP=1: quiet budget, UDP flood shed, auto learn on live UDP, transport path, public mesh peer dials |

```bash
go test ./pkg/protect -short
go test ./pkg/interfaces -run 'LiveUDP|LiveTCP|Protect'
make test-soak-protect
RUN_LIVE_INTEROP=1 go test ./tests/interop -run 'DoSProtect|DoSProtection'
```

FreeBSD, OpenBSD, and Haiku CI jobs run go test -short ./pkg/protect/ and transport protect tests in addition to pkg/sandbox and self-check. The test-extra soak matrix runs make test-soak-protect.

Config and threat scope: [Configuration](configuration.md#dos_protection-go-only), [Security](security.md#dos-protection-local-idsips).

### Test oracles

| Oracle | Location |
|--------|----------|
| Python crossref vectors | tests/crossref/ |
| Health counter deltas | pkg/health.TransportCounters / CounterSnapshot.Delta |
| Handshake / adversarial frames | pkg/packet/testdata/ |
| IFAC goldens | pkg/ifac unit tests |
| Sim path/hop asserts | pkg/transport/sim_assertions_test.go |

```bash
make test-oracle
```

### Smoke, acceptance, e2e, black box

```bash
make test-binary-smoke
make test-acceptance
make test-e2e
make test-blackbox
```

Notable additions: pkg/cli dump smoke via Main, pkg/librns.TestAcceptanceScaffoldMinimum, pkg/node.TestUDPPathE2E.

### Crossref tests

Location: tests/crossref/

Purpose: byte-level parity with Python reference output.

Workflow:

```bash
./tests/crossref/run_crossref.sh generate   # requires Python reference
./tests/crossref/run_crossref.sh test
./tests/crossref/run_crossref.sh all
```

Vectors are JSON with format version 5 (generate_vectors.py). The reference tree is fetched via rngit in run_crossref.sh.

Coverage includes identity, HKDF, HMAC, packet wire, announces, encryption, links, resources, channel envelopes, buffers, path requests.

Handshake decode trees for porters also live in pkg/packet/testdata/handshake_vectors.json (see [packet-debug.md](packet-debug.md)).

### Packet debug tools

- Wireshark Lua dissector: tools/wireshark/rns.lua
- reticulum-go dump / rgodump for hex and pcap
- reticulum-go snapshot / rgosnap for path and health JSON
- Timeline convention: [interop-timeline.md](interop-timeline.md)

```bash
go test ./pkg/packet/ -run 'TestHandshakeVector|TestTshark|TestDecode|TestPCAP'
go test ./pkg/health/ -run TestDrop
go test ./pkg/cli/ -run TestRunDump
```

### Interop tests

Location: tests/interop/

Live tests pair a Go process with Python helpers under tests/interop/py/. HDLC burst (TestLiveInteropHDLCBurst*) and Unpack hop-gate (TestLiveInteropUnpackOracleMatchesPython) cover stream coalescing and refuse-invalid parity.

Enable:

```bash
RUN_LIVE_INTEROP=1 go test -v ./tests/interop/...
```

Optional Python interpreter (prefer a venv or pipx install with rns==1.6.1):

```bash
sh scripts/ci/setup-venv-pip.sh 'rns==1.6.1'
PYTHON_INTEROP=.venv/bin/python RUN_LIVE_INTEROP=1 go test -v ./tests/interop/...
```

RNS 1.6.1 generates destination stamps by default at value 25, which is too slow for tests. Both sides use a low-cost convention so the wire shape stays stamped but generation is cheap: Go peers set `DestinationValue` in `interopPeerConfig()` (tests/interop/link_live_test.go) and the Python helpers set `DEST_VALUE` in their RNS config, both to 8.

The 1.6.1 wheel on PyPI was respun once as `rns-1.6.1-0` (2026-11-19) to hotfix the `rngit` media conversion helpers. `pip install rns==1.6.1` resolves to the hotfix build, which is the only version these tests are run against.

With pipx (`pipx install rns`), the interop harness and self-check also auto-detect `~/.local/share/pipx/venvs/rns/bin/python` when `PYTHON_INTEROP` is unset.

#### Debug harness

NomadNet relay, pageserver, and shared helpers use tests/interop/harness/.

| Variable | Behavior |
|----------|----------|
| INTEROP_ARTIFACTS=1 | Always keep artifact dirs (default: only when the test fails) |
| INTEROP_EVENTS=1 | Force event logging (also on when artifacts are enabled) |
| INTEROP_ARTIFACT_ROOT | Parent directory for durable artifact folders |

On failure (or with INTEROP_ARTIFACTS=1) the test logs the artifact path and the last events. Typical files:

| File | Contents |
|------|----------|
| events.jsonl | One JSON object per line (ts, src, event, kind, detail) |
| stderr.txt | Captured Python stderr (human RNS logs plus INTEROP_EVENT lines) |
| env.json | Selected interop env keys |

Python peers emit INTEROP_EVENT {...} on stderr via tests/interop/py/interop_events.py. Stdout tokens such as READY and REQUEST_OK are unchanged.

Example:

```bash
INTEROP_ARTIFACTS=1 INTEROP_ARTIFACT_ROOT=/tmp/rns-interop \
  RUN_LIVE_INTEROP=1 go test -v ./tests/interop/ -run 'TestLiveNomadNetLinkThroughGoRelay|TestLiveInteropPythonPageServerLargePageRequest'
```

| Test file | Topic |
|-----------|-------|
| link_live_test.go | Link sessions, resources, binary burst echo, Go->Python request |
| channel_buffer_live_test.go | Channel messages and buffer streams |
| rncp_blackhole_live_test.go | rncp file transfer and blackhole LINKIDENTIFY |
| auto_live_test.go | AutoInterface |
| ifac_live_test.go | IFAC |
| transport_path_live_test.go | Path requests |
| transport_relay_live_test.go | Transport relay |
| backbone_live_test.go | Backbone |
| quic_live_test.go | QUIC Go-Go echo (no Python peer) |
| pipe_live_test.go | PipeInterface with Python echo |
| modem73_live_test.go | Modem73Interface (fake KISS/control, optional modem73 binary audio loop via MODEM73_BIN + pactl) |
| sdr_live_test.go | SDRInterface mock exchange (RUN_LIVE_SDR=1) |
| shared_rpc_live_test.go | Shared-instance RPC (TCP and Unix on Linux) |
| pageserver_live_test.go | Pageserver example |
| nomadnet_crawl_live_test.go | Nomadnet crawl |
| nomadnet_relay_live_test.go | NomadNet through Go mesh relay |
| path_cp_live_test.go | path and rgocp utilities |
| i2p_live_test.go | I2PInterface Go and Python (needs SAM) |
| directory_outgoing_live_test.go | Public directory clearnet TCP peers |

### Package-specific live tests

| Package | Env var |
|---------|---------|
| pkg/i2p, pkg/interfaces I2P | RUN_LIVE_I2P=1 (optional I2P_SAM_ADDRESS, I2P_DIRECTORY_URL) |
| pkg/blackhole | RUN_PY_INTEROP=1 |
| pkg/discovery | RUN_PY_INTEROP=1 |
| pkg/lxstamper | RUN_PY_INTEROP=1 (LXStamper) |

### End-to-end daemon tests

cmd/reticulum-go/ contains controlapi_e2e_test.go, reload_e2e_test.go, and related tests.

### Host self-check

reticulum-go self-check is a host OS preflight. It validates that platform features work on the machine under test (crypto, identity file backend, sandbox, securemem, loopback interfaces, daemon with sandbox, shared-instance RPC, and on Unix a SIGHUP config/interface reload).

```bash
make test-self-check
# or
./bin/reticulum-go self-check --json --full
```

Flags:

| Flag | Behavior |
|------|----------|
| --json | Machine-readable report |
| --quick | Core and platform only (no loopback or daemon) |
| --full | Also probe QUIC, HTTPS, VSOCK, Pipe, and Serial |
| --interop | Optional external tools (crossref vectors, Python RNS, binding CLIs) |
| --strict | Treat warnings as failures |
| --binary PATH | Binary used for CLI and daemon checks |

Environment:

| Variable | Behavior |
|----------|----------|
| RETICULUM_SELF_CHECK=1 | Used by CI wrappers that invoke the same checklist |
| RETICULUM_SELF_CHECK_INTEROP=1 | Enables the interop tier |
| RETICULUM_TEST_KEYRING=1 | Require Linux keyring round-trip (fail if unavailable) |

Exit code is non-zero on any fail result. With --strict, warnings also fail.

Daemon checks include Control API health with sandbox enabled, shared-instance GetInterfaceStats RPC, and (except Windows, FreeBSD CapEnter, and OpenBSD unveil+pledge) SIGHUP reload of a UDP interface.

CI runs self-check on Linux (amd64 and arm64), macOS, Windows, FreeBSD, and OpenBSD. Extra Linux arches (386, arm GOARM=6, riscv64, ppc64le, ppc64) run via qemu-user-static (make test-self-check-386, test-self-check-arm, test-self-check-riscv64, test-self-check-ppc64le, test-self-check-ppc64). Android emulator self-check is a separate workflow (selfcheck-android.yml) on schedule or workflow_dispatch.

NetBSD is not in CI. Run reticulum-go self-check manually on that host.

### Static footgun scan

reticulum-go zen scans Go sources (and optional Python with -python) for path and link anti-patterns: RequestPath or HasPath loops, Establish before AwaitPath, link use without callbacks, announce bursts, and legacy 15 second timeouts. It is a developer tool, not a runtime check. No daemon is required.

```bash
make build
./bin/reticulum-go zen ./...
./bin/reticulum-go zen -list-rules
./bin/reticulum-go zen -fix ./pkg/myapp/...
```

-fix applies only safe edits (checking RequestPath errors in functions that return error). Warnings without -fix exit non-zero so CI can gate on the scan.

Package tests live in pkg/zenfix/. Full flag and rule reference: [CLI utilities](utilities.md#rgozen).

## Vendoring

Third-party source is committed under `vendor/`. Ordinary builds and tests use that tree with `GOFLAGS=-mod=vendor` and `GOPROXY=off` (set by the Makefile). That keeps air-gapped builds reliable, makes dependency upgrades reviewable as diffs, and matches CI.

Versions and checksums remain in `go.mod` / `go.sum`. Scripts that install standalone CLI tools (revive, gosec, and similar) temporarily clear those env flags to fetch the tool binary. Project code itself always compiles from `vendor/`.

Refresh after dependency changes:

```bash
make vendor-sync
# or
make deps
```

`make vendor-sync` requires `LIBS_ROOT` pointing at the Reticulum-Go-Deps sibling tree for the bzip2, msgpack, pbt and tagparser replace directives. The protocols module is in this tree under `protocols/`, and its `go.mod` replaces the root module with `..`. Commit `go.mod`, `go.sum`, and `vendor/` after refresh.

`go mod vendor` regenerates vendor/ from scratch and deletes local patches applied on top of upstream code (currently the linux/ppc64 serial stub). `vendor-sync` reapplies them automatically through `scripts/vendor-patches.sh`. After any manual `go mod vendor` run `make vendor-patch`. `make vendor-check` fails if the patches are missing and runs in `make ci`.

The repository contains two modules: the root stack and `protocols/` (LXMF, LXST, MF, RRC). Each has its own `go.mod` and `vendor/` policy. Both modules vendor their dependencies and build with `GOFLAGS=-mod=vendor`. Build and test the nested module with `task protocols-build` and `task protocols-test`.

The docs site is a [Zensical](https://zensical.org) site configured by `zensical.toml` at the repository root, with `docs/en` as the docs directory. `task docs-serve` runs `scripts/docs-bundle.py` and then `zensical serve` for a live preview at http://127.0.0.1:1313/; `task docs-build` writes the static site to `site/`. `scripts/docs.sh` creates a `.docs-venv` with the pinned tooling from `docs/requirements-docs.txt` on first use. `scripts/docs-bundle.py` reads the page order from `zensical.toml`'s nav and writes a Markdown ZIP, a PDF rendered with headless Chromium, and a hand assembled EPUB 3 to `docs/en/assets/downloads/` (gitignored). Deploys are handled by mike in the docs workflow: pushes to master publish `dev`, releases publish their version and the `latest` alias, and `mike set-default` points the site root at `latest`.

Day-to-day clones only need `vendor/` to build offline. Sibling checkouts are only required when re-vendoring first-party libraries. `examples/wasm` and `examples/pageserver` keep their own `go.mod` / `vendor/` trees. Docker configs under `docker/` copy those folders for offline image builds.

## CI overview

GitHub Actions workflows in .github/workflows/:

| Workflow | Role |
|----------|------|
| ci.yml | Build, test, reproducibility, OS self-check (Linux amd64 v1+v3, i686/386, arm64, arm, riscv64, ppc64le, ppc64, mips, s390x, plus Windows, macOS, *BSD, Solaris, illumos, AIX, Android arm64, wasm, and qemu-user self-check for 386/arm/riscv64/ppc64le/ppc64) |
| selfcheck-android.yml | Android emulator self-check (nightly / manual) |
| security.yml | Gosec, govulncheck, Trivy, SBOM dispatch |
| codeql.yml | CodeQL for Go, JS/TS, Python, and Actions workflows |
| dependency-review.yml | PR dependency and advisory gate |
| publish.yml | Tagged releases, cosign attestations |

After a tagged GitHub release finishes, the same assets can be published to the rngit repository (`rns://06a54b505bb67b25ef3f8097e8001edc/public/Reticulum-Go`) with `task release-rngit TAG=<tag>`. Run it with `ARGS=--dry-run` first to generate the signatures and manifest without uploading. See the releasing section in CONTRIBUTING.md.

CI uses Go 1.27.4 via actions/setup-go in .github/actions/setup-ci with GOTOOLCHAIN=local and vendored modules. Actions are SHA-pinned.

## Cross-compilation

```bash
make build-linux
make build-windows
make build-darwin
make build-all
```

make build-linux always emits linux-amd64 v1 and v3 together, plus linux-386 and linux-i686. make build-all covers every CGO-free GOOS/GOARCH pair that compiles (see scripts/build-release-targets.sh).

Legacy Windows uses go-legacy-win7 (make build-windows-legacy).

## WebAssembly development

```bash
make build-wasm
make test-wasm
```

Manual WASM binary:

```bash
mkdir -p bin
GOOS=js GOARCH=wasm go build -ldflags="-s -w" -o bin/reticulum-go.wasm ./cmd/reticulum-wasm
```

See [Embedding and WebAssembly](embedding-and-wasm.md).

## librns shared library

```bash
make build-librns
make -C `bindings/c/examples`/smoke
./bindings/c/examples/smoke/librns-smoke
```

Needs a C toolchain and CGO. Daemon builds stay CGO_ENABLED=0. See [librns](librns.md).

## Odin bindings

```bash
make build-librns
make test-odin
```

Requires the Odin compiler on PATH (CI installs a pinned monthly release via scripts/ci/setup-odin.sh, job Odin bindings). Package lives under bindings/odin. See [librns](librns.md#odin-bindings).

## Zig bindings

```bash
make build-librns
make test-zig
```

Requires Zig 0.16.0 or later on PATH (CI installs a pinned release via scripts/ci/setup-zig.sh, job Zig bindings). Package lives under bindings/zig. See [librns](librns.md#zig-bindings).

## C++ bindings

```bash
make build-librns
make test-cpp
```

Requires CMake and a C++17 compiler on PATH (CI job C++ bindings). Package lives under bindings/cpp. See [librns](librns.md#c-bindings).

## Dart bindings

```bash
make build-librns
make test-dart
```

Requires the Dart SDK on PATH (CI pins 3.11.4, job Dart bindings) and CGO for librns.so FFI smoke tests. Package and examples live under bindings/dart. See [librns Dart FFI](librns.md#dart-ffi-bindings) and [Control API](control-api.md#dart-and-flutter).

## Rust bindings

```bash
make build-librns
make test-rust
```

Requires cargo on PATH (CI job Rust bindings). Package and examples live under bindings/rust.

## Python bindings

```bash
make build-librns
make test-python
```

Requires python3 on PATH (CI job Python bindings). Package and examples live under bindings/python.

## Lua bindings

```bash
make build-librns
make test-lua
```

Requires LuaJIT on PATH (CI job Lua bindings). Package and examples live under bindings/lua.

## Swift bindings

```bash
make build-librns
make test-swift
```

Requires swift on PATH (CI pins 6.0.3 via scripts/ci/setup-swift.sh, job Swift bindings). Package and examples live under bindings/swift.

## Java bindings

```bash
make build-librns
make test-java
```

Requires javac on PATH (CI uses Temurin 17, job Java bindings). Package and examples live under bindings/java. JNA is fetched on first build.

## Kotlin bindings

```bash
make build-librns
make test-kotlin
```

Requires kotlinc and javac on PATH (CI pins Kotlin 2.1.10 via scripts/ci/setup-kotlin.sh, job Kotlin bindings). Package and examples live under bindings/kotlin and depend on bindings/java.

## C ABI examples

```bash
make build-librns
make test-c
```

Builds and runs bindings/c/examples (smoke plus page-fetch/pageserver compile). Binding CI jobs also run make -C bindings/`<lang>` examples.

## Adding a change safely

1. Write or extend unit tests in the affected package
2. If wire format changes, update crossref vectors and Python reference together
3. Run make check locally
4. For protocol behavior, add or extend interop test when feasible
5. Update [Compatibility](compatibility.md) and [COMPATIBILITY.md](https://github.com/Quad4-Software/Reticulum-Go/blob/master/COMPATIBILITY.md) if parity status changes

## Memory diagnostics on a running node

Three ways to inspect memory on a production node without restarting it:

- `rgostatus --memory` prints Go runtime stats (heap, stack, sys, goroutines, GC counters, the effective soft limit) and transport table sizes from the shared-instance RPC. Python shared instances answer it as unavailable.
- `SIGUSR1` (Unix) writes a pprof heap profile to `<config dir>/storage/heap-<nanoseconds>.pprof`. The newest five `heap-*.pprof` files are kept. Analyze offline with `go tool pprof -top <file>`.
- `RETICULUM_PPROF_ADDR=127.0.0.1:6060` binds a localhost-only net/http/pprof listener at daemon start. Fetch a profile with `go tool pprof http://127.0.0.1:6060/debug/pprof/heap`. Leave it unset on hosts where localhost is not trusted.

When a soft memory limit is in effect (always on current builds unless `GOMEMLIMIT` or `soft_memory_limit` overrides it), the daemon logs a warning once heap usage crosses 85 percent of the limit and re-arms below 70 percent. Setting `RETICULUM_HEAP_DUMP_ON_THRESHOLD=1` also writes a bounded heap profile to the storage directory on each crossing.

## Related documents

- [Security](security.md) for CI scan detail
- [Package map](package-map.md)
- [Examples](examples.md)
