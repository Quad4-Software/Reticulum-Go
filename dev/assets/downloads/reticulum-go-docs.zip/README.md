# Reticulum-Go Documentation (English)

System documentation, API references, and configuration guides for Reticulum-Go.

## About this documentation

These documents describe Reticulum-Go, a Go implementation of the [Reticulum Network Stack](https://reticulum.network/). Use them to integrate, operate, or extend the stack.

Documentation is organized by language under docs/. English lives in docs/en/. Additional languages can be added as sibling directories (for example docs/de/) without changing the English tree.

## Document index

| Document | Summary |
|----------|---------|
| [Overview](overview.md) | What Reticulum-Go is, goals, feature status, relationship to Python Reticulum |
| [Architecture](architecture.md) | Layered design, data flow, major components, deployment models |
| [Getting started](getting-started.md) | Requirements, build, install, first run, basic troubleshooting |
| [Configuration](configuration.md) | Config file format, paths, keys, interface blocks |
| [Package map](package-map.md) | pkg/ layout, responsibilities, entry points |
| [API reference](api-reference.md) | Task-first Go API: recipes, types, Python map, concurrency |
| [Transport](transport.md) | Routing, path table, announces, forwarding, persistence |
| [Interfaces](interfaces.md) | UDP, TCP, Auto, I2P, Backbone, Serial, WebSocket, QUIC, WebTransport, DNS rendezvous, VSOCK, HTTPS, IFAC, reconnect |
| [Identity and destinations](identity-and-destinations.md) | Keys, hashes, destination types, announces, requests |
| [Links, channels, and resources](links-channels-and-resources.md) | Links, reliable channel, stream buffer, file transfer |
| [Cryptography](cryptography.md) | Primitives, key formats, IFAC, ratchets, verification |
| [Security](security.md) | Reporting, sandbox, dos_protection, supply chain, release verification, local mesh health |
| [Compatibility](compatibility.md) | Parity with Python RNS, gaps, Go-only extensions |
| [Control API](control-api.md) | Localhost JSON and WebSocket API for non-Go clients, Dart and Flutter |
| [librns](librns.md) | C ABI map, supported surface, events, build and smoke, Odin bindings |
| [CLI utilities](utilities.md) | reticulum-go subcommands (status, slow, zen, id, probe, path, cp, pageserver), shared-instance RPC with Python |
| [Embedding and WebAssembly](embedding-and-wasm.md) | pkg/node, WASM, browser integration |
| [Firecracker microvm](microvm.md) | Guest rootfs, VSOCK host bridge, nested VM networking |
| [Development and testing](development-and-testing.md) | Make/manual targets, code quality, crossref, interop, CI |
| [Examples](examples.md) | Example programs and how to run them |

## Related files in the repository root

| File | Purpose |
|------|---------|
| [README.md](https://github.com/Quad4-Software/Reticulum-Go/blob/master/README.md) | Project entry point, features, install/build |
| [COMPATIBILITY.md](https://github.com/Quad4-Software/Reticulum-Go/blob/master/COMPATIBILITY.md) | Detailed compatibility matrix and interop methodology (also summarized in [compatibility.md](compatibility.md)) |
| [deviations.md](deviations.md) | Intentional differences from Python RNS and local hardening bounds |
| [AUTHORS.md](https://github.com/Quad4-Software/Reticulum-Go/blob/master/AUTHORS.md) | Authorship and attribution |
| [SECURITY.md](https://github.com/Quad4-Software/Reticulum-Go/blob/master/SECURITY.md) | Vulnerability reporting and supply-chain detail (also summarized in [security.md](security.md)) |
| [LICENSE](https://github.com/Quad4-Software/Reticulum-Go/blob/master/LICENSE) | Reticulum License |

## External references

- [Reticulum manual](https://reticulum.network/manual/reference.html) (Python API and protocol authority)
- [Reticulum cryptography overview](https://reticulum.network/crypto.html)
- [Python reference implementation](https://github.com/markqvist/Reticulum)

Go application authors should start with [API reference](api-reference.md) and [Examples](examples.md), then use the Python manual when comparing wire semantics.
